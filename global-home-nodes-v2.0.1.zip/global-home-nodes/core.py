#!/usr/bin/env python3
"""Pure configuration/validation functions. No production paths or credentials."""
import ast
import base64
import hashlib
import ipaddress
import json
import re
import secrets
import uuid
from urllib.parse import quote, urlencode

def host(value):
    if not isinstance(value,str) or len(value)>253:raise ValueError('地址格式错误')
    try:return str(ipaddress.ip_address(value))
    except ValueError:pass
    if not re.fullmatch(r'(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?',value) or '..' in value:
        raise ValueError('只接受IP或域名，不接受URL、路径或端口')
    if any(not label or len(label)>63 or label.startswith('-') or label.endswith('-') for label in value.split('.')):raise ValueError('域名格式错误')
    return value.lower()

def port(value):
    if isinstance(value,bool) or not re.fullmatch(r'[0-9]{1,5}',str(value)):raise ValueError('端口必须是整数')
    n=int(value)
    if not 1<=n<=65535:raise ValueError('端口范围1–65535')
    return n

def validate_provider(doc):
    if not isinstance(doc,dict) or not isinstance(doc.get('nodes'),list):raise ValueError('缺少供应商nodes列表')
    server=host(doc.get('listen_ip'))
    if not 1<=len(doc['nodes'])<=150:raise ValueError('出口数异常')
    out=[];seen=set()
    for raw in doc['nodes']:
        if not isinstance(raw,dict):raise ValueError('节点格式异常')
        name=raw.get('info')
        if not isinstance(name,str) or not name.strip() or len(name)>180 or any(ord(c)<32 for c in name):raise ValueError('出口名称异常')
        if name in seen:raise ValueError('供应商同名出口，拒绝猜测')
        seen.add(name)
        user=raw.get('socks_user');password=raw.get('socks_pass')
        for val in [user,password]:
            if not isinstance(val,str) or not 1<=len(val.encode())<=255 or any(c in val for c in '\x00\r\n'):raise ValueError('SOCKS认证参数异常')
        if ':' in user:raise ValueError('curl测试不支持含冒号的SOCKS用户名，拒绝错误解析')
        n=dict(name=name,server=server,port=port(raw.get('port')),username=user,password=password)
        n['key']=hashlib.sha256(name.encode()).hexdigest()[:24]
        out.append(n)
    if len({n['key'] for n in out})!=len(out):raise ValueError('名称哈希冲突')
    return out

def parse_trace(raw):
    if len(raw)>80*1024*1024:raise ValueError('追踪日志过大，停止解析')
    docs=[];decoder=json.JSONDecoder()
    for match in re.finditer(r'"(?:[^"\\]|\\.)*"',raw):
        try:
            value=ast.literal_eval(match.group())
            try:value=value.encode('latin1').decode('utf-8')
            except (UnicodeEncodeError,UnicodeDecodeError):pass
        except (ValueError,SyntaxError):continue
        for start in re.finditer(r'\{',value):
            try:d,_=decoder.raw_decode(value[start.start():])
            except ValueError:continue
            if isinstance(d,dict) and isinstance(d.get('nodes'),list) and 'listen_ip' in d and d not in docs:docs.append(d)
    if len(docs)!=1:raise ValueError('未找到唯一完整授权出口响应；供应商协议可能已变更。可用供应商导出的JSON导入，拒绝猜测或绕过认证')
    return validate_provider(docs[0])

def credentials(rows,previous=None):
    old={n['key']:n for n in (previous or {}).get('nodes',[])}
    return [dict(n,uuid=old[n['key']]['uuid'] if n['key'] in old else str(uuid.uuid4())) for n in rows]

def server_config(rows,settings,listen='0.0.0.0'):
    if not rows:raise ValueError('没有通过检测的出口')
    bridge=settings['bridge_port'];sni=host(settings['sni'])
    outs=[{'tag':'block','protocol':'blackhole'}]
    rules=[{'type':'field','network':'udp','outboundTag':'block'},
           {'type':'field','inboundTag':['handshake'],'outboundTag':'exit-'+rows[0]['key']}]
    users=[]
    for n in rows:
        email=n['key']+'@home';tag='exit-'+n['key']
        users.append({'id':n['uuid'],'flow':'xtls-rprx-vision','email':email})
        outs.append({'tag':tag,'protocol':'socks','settings':{'servers':[{'address':n['server'],'port':n['port'],'users':[{'user':n['username'],'pass':n['password']}]}]},'streamSettings':{'sockopt':{'interface':settings['interface']}}})
        rules.append({'type':'field','inboundTag':['entry'],'user':[email],'outboundTag':tag})
    rules.append({'type':'field','inboundTag':['entry'],'outboundTag':'block'})
    return {'log':{'loglevel':'warning'},'inbounds':[
        {'tag':'entry','listen':listen,'port':settings['internal_port'],'protocol':'vless','settings':{'clients':users,'decryption':'none'},'streamSettings':{'network':'tcp','security':'reality','realitySettings':{'show':False,'dest':f'127.0.0.1:{bridge}','xver':0,'serverNames':[sni],'privateKey':settings['private_key'],'shortIds':[settings['short_id']]}}},
        {'tag':'handshake','listen':'127.0.0.1','port':bridge,'protocol':'dokodemo-door','settings':{'address':sni,'port':443,'network':'tcp'}}
    ],'outbounds':outs,'routing':{'domainStrategy':'AsIs','rules':rules}}

def client_config(rows,settings,remote,remote_port,local_ports):
    ins=[];outs=[{'tag':'block','protocol':'blackhole'}];rules=[]
    for n,p in zip(rows,local_ports):
        tag='test-'+n['key'];ins.append({'tag':tag,'listen':'127.0.0.1','port':p,'protocol':'socks','settings':{'auth':'noauth','udp':False}})
        outs.append({'tag':tag,'protocol':'vless','settings':{'vnext':[{'address':remote,'port':remote_port,'users':[{'id':n['uuid'],'encryption':'none','flow':'xtls-rprx-vision'}]}]},'streamSettings':{'network':'tcp','security':'reality','realitySettings':{'serverName':settings['sni'],'publicKey':settings['public_key'],'fingerprint':'chrome','shortId':settings['short_id']}}})
        rules.append({'type':'field','inboundTag':[tag],'outboundTag':tag})
    return {'log':{'loglevel':'warning'},'inbounds':ins,'outbounds':outs,'routing':{'rules':rules}}

def endpoint(value):return '['+value+']' if ':' in value else value

def exports(rows,settings):
    proxies=[];links=[];backends=[]
    for n in rows:
        query={'encryption':'none','security':'reality','sni':settings['sni'],'fp':'chrome','pbk':settings['public_key'],'sid':settings['short_id'],'type':'tcp','flow':'xtls-rprx-vision'}
        links.append('vless://'+n['uuid']+'@'+endpoint(settings['public_host'])+':'+str(settings['external_port'])+'?'+urlencode(query)+'#'+quote(n['name'],safe=''))
        backends.append('socks5://'+quote(n['username'],safe='')+':'+quote(n['password'],safe='')+'@'+endpoint(n['server'])+':'+str(n['port'])+'#'+quote(n['name'],safe=''))
        proxies.append({'name':n['name'],'type':'vless','server':settings['public_host'],'port':settings['external_port'],'uuid':n['uuid'],'network':'tcp','tls':True,'udp':False,'flow':'xtls-rprx-vision','servername':settings['sni'],'client-fingerprint':'chrome','reality-opts':{'public-key':settings['public_key'],'short-id':settings['short_id']}})
    # JSON is a strict subset of YAML 1.2 and accepted by Mihomo; no PyYAML dependency.
    names=[n['name'] for n in rows];group='GLOBAL-HOME'
    while group in names:group+='-SELECT'
    clash={'mixed-port':7890,'allow-lan':False,'mode':'rule','log-level':'warning','proxies':proxies,'proxy-groups':[{'name':group,'type':'select','proxies':names}],'rules':['MATCH,'+group]}
    raw='\n'.join(links)+'\n'
    return {'vless.txt':raw,'clash.yaml':json.dumps(clash,ensure_ascii=False,indent=2)+'\n','shadowrocket-base64.txt':base64.b64encode(raw.encode()).decode()+'\n','socks5-private.txt':'\n'.join(backends)+'\n'}
