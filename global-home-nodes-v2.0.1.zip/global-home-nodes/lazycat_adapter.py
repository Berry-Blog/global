#!/usr/bin/env python3
"""LazyCat Global adapter, kept replaceable independently from node state."""
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import tempfile

from core import parse_trace, validate_provider

ADAPTER_VERSION = "1.0.0"
APP = Path("/opt/global-home-nodes")


def extract(import_path=None):
    """Read an explicit authorized JSON export or the read-only proxy menu."""
    if import_path:
        path = Path(import_path)
        if path.stat().st_size > 1024 * 1024:
            raise ValueError("导入JSON过大")
        return validate_provider(json.loads(path.read_text(encoding="utf-8")))

    proxy = Path("/usr/local/bin/proxy")
    if not proxy.is_file():
        raise RuntimeError("缺少供应商proxy工具；也可以用 --import-json 导入授权出口")
    print("将临时读取本机 proxy 的出口菜单，脚本不会切换当前出口。", flush=True)
    if input("只读取你有权使用的出口认证参数，输入 YES：").strip() != "YES":
        raise RuntimeError("未授权读取，已停止")

    temp_root = "/run" if Path("/run").is_dir() else "/tmp"
    with tempfile.TemporaryDirectory(prefix="global-home-lazycat-", dir=temp_root) as directory:
        trace = Path(directory) / "proxy.trace"
        trace.write_bytes(b"")
        os.chmod(trace, 0o600)
        with open(os.devnull, "wb") as sink:
            def set_limit():
                resource.setrlimit(resource.RLIMIT_FSIZE, (80 * 1024 * 1024, 80 * 1024 * 1024))

            process = subprocess.Popen(
                ["expect", str(APP / "extract.exp"), str(trace)],
                stdout=sink,
                stderr=sink,
                start_new_session=True,
                preexec_fn=set_limit,
            )
            try:
                code = process.wait(timeout=130)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=10)
                raise RuntimeError("供应商菜单读取超时；临时数据已清理") from None
            finally:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass

        if code != 0:
            raise RuntimeError(
                "LazyCat菜单格式不受当前适配器支持或系统禁止ptrace；"
                "停止读取，可用供应商导出的授权JSON，或单独更新LazyCat适配器"
            )
        if trace.stat().st_size > 80 * 1024 * 1024:
            raise RuntimeError("追踪内容超过大小上限，停止解析")
        return parse_trace(trace.read_text(errors="replace"))
