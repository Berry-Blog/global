# Global Home v2.0.1 使用说明

## 安装

```sh
sh global-home-nodes-install-v2.0.1.sh --verify
sh global-home-nodes-install-v2.0.1.sh
```

已安装旧版的机器可运行 v2.0.1 安装器更新管理程序。

## 常用命令

```sh
global-home-nodes status
global-home-nodes refresh
global-home-nodes update
global-home-nodes update --check-only
global-home-nodes refresh --import-json /root/my-authorized-exits.json
global-home-nodes uninstall
```
