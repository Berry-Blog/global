#!/bin/sh
set -eu
umask 077

[ "$(id -u)" -eq 0 ] || { echo '请用root运行。'; exit 1; }
SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
APP=/opt/global-home-nodes
CONF=/etc/global-home-nodes
CLI=/usr/local/bin/global-home-nodes
MARKER=global-home-nodes-v2
OLD_MARKER=$(cat "$APP/INSTALLER-MARKER" 2>/dev/null || true)

echo 'Global Home 多家宽管理工具 v2.0.1'
echo 'update 只更新管理程序和 LazyCat 适配器；refresh 才会读取出口并更新本工具自己的节点配置。'
echo '本工具使用独立 Xray 服务，不改动系统现有 sing-box、proxy 或 TG 服务。'

if [ -e "$CLI" ] && ! grep -q 'GLOBAL_HOME_NODES_CLI_V2' "$CLI" 2>/dev/null; then
  echo "发现已有命令 $CLI，且不是本工具创建的；拒绝覆盖。" >&2
  exit 1
fi

if [ -e "$APP" ]; then
  case "$OLD_MARKER" in
    global-home-nodes-v1|global-home-nodes-v2) ;;
    *) echo '发现同名目录但没有本工具安装标记，停止。' >&2; exit 1 ;;
  esac
  [ -d "$APP" ] || { echo '程序目录不是普通目录，停止。' >&2; exit 1; }
  if [ -e "$CONF/current" ] && [ ! -L "$CONF/current" ]; then
    echo '配置 current 不是本工具的代际链接，停止。' >&2
    exit 1
  fi
elif [ -e "$CONF" ]; then
  echo '发现节点配置目录但没有本工具程序目录；拒绝接管。' >&2
  exit 1
else
  for path in /etc/init.d/global-home-nodes /etc/systemd/system/global-home-nodes.service; do
    [ ! -e "$path" ] || { echo "发现已有服务 $path，停止。" >&2; exit 1; }
  done
fi

# BEGIN APK DEPENDENCY FLOW
apk_log() {
  printf '%s\n' "$*"
  printf '%s\n' "$*" >> "$APK_INSTALL_LOG"
}

apk_with_deadline() {
  wall_limit=$1
  shift
  if command -v timeout >/dev/null 2>&1; then
    timeout -k 10 "$wall_limit" "$@"
  elif command -v busybox >/dev/null 2>&1; then
    busybox timeout -k 10 "$wall_limit" "$@"
  else
    printf '%s\n' '无法执行有时限的 APK 操作：系统没有 timeout 或 BusyBox timeout。' >&2
    return 127
  fi
}

run_apk_bounded() {
  phase=$1
  wall_limit=$2
  shift 2
  apk_log "[apk] phase=$phase started; wall-limit=${wall_limit}s, kill-grace=10s, network-idle=30s, repository-lock=15s"
  if [ "$phase" = fetch ]; then
    if apk_with_deadline "$wall_limit" apk --update-cache --timeout 30 --wait 15 "$@" >> "$APK_INSTALL_LOG" 2>&1; then
      apk_log "[apk] phase=$phase completed"
      return 0
    else
      APK_PHASE_STATUS=$?
    fi
  elif [ "$APK_NETWORK_NO_SUPPORTED" -eq 1 ]; then
    if apk_with_deadline "$wall_limit" apk --network=no --timeout 30 --wait 15 "$@" >> "$APK_INSTALL_LOG" 2>&1; then
      apk_log "[apk] phase=$phase completed"
      return 0
    else
      APK_PHASE_STATUS=$?
    fi
  else
    if apk_with_deadline "$wall_limit" apk --timeout 30 --wait 15 "$@" >> "$APK_INSTALL_LOG" 2>&1; then
      apk_log "[apk] phase=$phase completed"
      return 0
    else
      APK_PHASE_STATUS=$?
    fi
  fi
  apk_log "[apk] phase=$phase failed (exit=$APK_PHASE_STATUS); root cause has not been established. Full diagnostic log: $APK_INSTALL_LOG"
  case "$APK_PHASE_STATUS" in
    124|137|143) apk_log "[apk] phase=$phase reached its ${wall_limit}s wall-clock limit." ;;
  esac
  tail -n 35 "$APK_INSTALL_LOG" >&2
  return 1
}

install_alpine_dependencies() {
  APK_LOG_DIR=${GLOBAL_HOME_NODES_APK_LOG_DIR:-/var/log/global-home-nodes}
  APK_STAGE_ROOT=${GLOBAL_HOME_NODES_APK_STAGE_ROOT:-/tmp}
  if ! mkdir -p "$APK_LOG_DIR" "$APK_STAGE_ROOT"; then
    echo "无法创建 APK 日志或暂存目录：$APK_LOG_DIR" >&2
    return 1
  fi
  chmod 700 "$APK_LOG_DIR"
  APK_INSTALL_LOG="$APK_LOG_DIR/apk-install-v2.0.1-$(date -u +%Y%m%dT%H%M%SZ)-$$.log"
  if ! (umask 077; : > "$APK_INSTALL_LOG"); then
    echo "无法创建 APK 诊断日志：$APK_INSTALL_LOG" >&2
    return 1
  fi
  apk_log '[apk] Resolving and staging the complete repository dependency closure before installation.'
  apk_log '[apk] APK signature verification remains enabled; --allow-untrusted is not used.'
  apk_log '[apk] The earlier APK stall root cause has not been established; this run records the failing phase.'

  APK_HELP=$(apk --help 2>&1 || true)
  case "$APK_HELP" in
    *--network*) APK_NETWORK_NO_SUPPORTED=1 ;;
    *) APK_NETWORK_NO_SUPPORTED=0 ;;
  esac

  APK_STAGE_DIR=$(mktemp -d "$APK_STAGE_ROOT/global-home-nodes-apk.XXXXXX") || {
    apk_log "[apk] Cannot create temporary package directory; diagnostic log: $APK_INSTALL_LOG"
    return 1
  }

  if ! run_apk_bounded fetch 360 fetch --recursive --output "$APK_STAGE_DIR" python3 curl expect strace coreutils ca-certificates; then
    rm -rf -- "$APK_STAGE_DIR"
    return 1
  fi

  APK_COUNT=0
  for APK_FILE in "$APK_STAGE_DIR"/*.apk; do
    [ -f "$APK_FILE" ] || continue
    APK_COUNT=$((APK_COUNT + 1))
    apk_log "[apk] staged ${APK_FILE##*/}"
  done
  if [ "$APK_COUNT" -eq 0 ]; then
    apk_log "[apk] fetch produced no APK files; dependency resolution stopped. Full diagnostic log: $APK_INSTALL_LOG"
    rm -rf -- "$APK_STAGE_DIR"
    return 1
  fi

  for APK_PACKAGE in python3 curl expect strace coreutils ca-certificates; do
    APK_FOUND=0
    for APK_FILE in "$APK_STAGE_DIR/$APK_PACKAGE"-*.apk; do
      if [ -f "$APK_FILE" ]; then APK_FOUND=1; break; fi
    done
    if [ "$APK_FOUND" -ne 1 ]; then
      apk_log "[apk] Required package $APK_PACKAGE was not staged; dependency resolution stopped. Full diagnostic log: $APK_INSTALL_LOG"
      rm -rf -- "$APK_STAGE_DIR"
      return 1
    fi
  done

  # Pass every resolved APK path through both solver and installer. This retains
  # repository-selected split packages (for example python3-pyc,
  # python3-pycache-pyc0, xz-libs, and sqlite-libs) without guessing names.
  if ! run_apk_bounded simulate 120 add --simulate "$APK_STAGE_DIR"/*.apk; then
    rm -rf -- "$APK_STAGE_DIR"
    return 1
  fi
  if ! run_apk_bounded install 360 add "$APK_STAGE_DIR"/*.apk; then
    rm -rf -- "$APK_STAGE_DIR"
    return 1
  fi

  rm -rf -- "$APK_STAGE_DIR"
  apk_log "[apk] Dependency installation completed. Diagnostic log: $APK_INSTALL_LOG"
}
# END APK DEPENDENCY FLOW

if [ -f /etc/alpine-release ]; then
  install_alpine_dependencies
elif command -v apt-get >/dev/null 2>&1 && command -v systemctl >/dev/null 2>&1; then
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3 curl expect strace coreutils ca-certificates
else
  echo '仅支持 Alpine/OpenRC 或 Debian/Ubuntu/systemd。' >&2
  exit 1
fi
for cmd in python3 curl expect strace sha256sum; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "缺少依赖：$cmd" >&2; exit 1; }
done

if [ -d "$APP" ]; then
  backup=/root/global-home-nodes-code-backups/$(date +%Y%m%d-%H%M%S)-v2
  mkdir -p "$backup"
  chmod 700 /root/global-home-nodes-code-backups "$backup"
  for file in core.py deploy.py lazycat_adapter.py extract.exp VERSION.json; do
    [ ! -f "$APP/$file" ] || cp -p "$APP/$file" "$backup/$file"
  done
  echo "旧管理程序备份：$backup"
fi

mkdir -p "$APP" "$CONF"
chmod 700 "$APP" "$CONF"
chown root:root "$APP" "$CONF"
for file in core.py deploy.py lazycat_adapter.py extract.exp VERSION.json; do
  install -o root -g root -m 700 "$SOURCE/$file" "$APP/$file"
done
printf '%s\n' "$MARKER" > "$APP/INSTALLER-MARKER"
chmod 600 "$APP/INSTALLER-MARKER"

tmp_cli=$(mktemp /usr/local/bin/.global-home-nodes.XXXXXX)
trap 'rm -f "$tmp_cli"' EXIT HUP INT TERM
cat > "$tmp_cli" <<'EOF'
#!/bin/sh
# GLOBAL_HOME_NODES_CLI_V2
exec python3 /opt/global-home-nodes/deploy.py "$@"
EOF
install -o root -g root -m 755 "$tmp_cli" "$CLI"
rm -f "$tmp_cli"
trap - EXIT HUP INT TERM

if [ -L "$CONF/current" ]; then
  echo '管理程序已升级。现有节点、UUID、Reality 密钥、端口和服务配置均保留；需要更新出口时另行运行：'
  echo '  global-home-nodes refresh'
  exit 0
fi

exec python3 "$APP/deploy.py" deploy "$@"
