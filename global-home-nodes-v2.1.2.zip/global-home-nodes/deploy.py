#!/usr/bin/env python3
"""Global Home manager. Updates only its own application directory."""
import argparse
import concurrent.futures
import contextlib
import datetime
import fcntl
import hashlib
import io
import ipaddress
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import tempfile
import time
import urllib.request
import zipfile
from core import host,port,credentials,server_config,client_config,exports
from lazycat_adapter import extract
from update_manager import update as update_manager
from relay_export import export_from_runtime, load_runtime_generation, read_runtime_export

APP=Path('/opt/global-home-nodes')
ROOT=Path('/etc/global-home-nodes')
SERVICE='global-home-nodes'
TOOL_VERSION='2.1.2'
VERSION='v26.4.25'
ASSETS={
 'x86_64':('Xray-linux-64.zip','a4ec9c037933b6730fb29e4f7a6674647f40b0b9f40870411071dd6382ea87a8'),
 'aarch64':('Xray-linux-arm64-v8a.zip','020416fa7e1b1b04c4f97209b33f1bd4683e15272feda48c769ae2c9beb1c3de')}

def run(args,**kw):
    try:return subprocess.run(args,capture_output=True,timeout=kw.pop('timeout',45),**kw)
    except subprocess.TimeoutExpired:raise RuntimeError('命令超时：'+Path(args[0]).name) from None

def write(path,obj):
    data=obj if isinstance(obj,bytes) else (obj if isinstance(obj,str) else json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode()
    with open(path,'wb') as f:
        os.chmod(path,0o600);f.write(data);f.flush();os.fsync(f.fileno())

def key_valid(value):
    try:return isinstance(value,str) and len(__import__('base64').urlsafe_b64decode(value+'==='))==32
    except Exception:return False

def ensure_xray():
    p=APP/'xray';manifest=APP/'binary.json'
    if p.exists():
        if not manifest.exists():raise RuntimeError('发现来源不明的同名Xray文件，拒绝覆盖')
        meta=json.loads(manifest.read_text())
        if meta.get('version')!=VERSION or hashlib.sha256(p.read_bytes()).hexdigest()!=meta.get('sha256'):raise RuntimeError('已安装Xray校验不符，停止')
        return p
    arch=platform.machine()
    if arch not in ASSETS:raise RuntimeError('暂只支持Linux x86_64/aarch64')
    name,digest=ASSETS[arch];url=f'https://github.com/XTLS/Xray-core/releases/download/{VERSION}/{name}'
    print('下载官方固定版本 Xray '+VERSION+' 并核验SHA256…',flush=True)
    with tempfile.TemporaryDirectory(prefix='home-nodes-download-') as tmp:
        dest=Path(tmp)/'xray.zip'
        q=run(['curl','-q','--noproxy','*','--proto','=https','--tlsv1.2','-fL','--connect-timeout','12','--max-time','180','-o',str(dest),url],timeout=190)
        if q.returncode:raise RuntimeError('官方下载失败；先修复本机联网，脚本不会关闭TLS验证或使用第三方镜像')
        if dest.stat().st_size>120*1024*1024 or hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:raise RuntimeError('Xray下载包校验失败')
        with zipfile.ZipFile(dest) as z:
            member=z.getinfo('xray')
            if member.file_size>150*1024*1024:raise RuntimeError('二进制尺寸异常')
            binary=z.read('xray')
        temp=APP/'xray.next';write(temp,binary);temp.chmod(0o755);temp.replace(p)
        write(manifest,{'version':VERSION,'archive_sha256':digest,'sha256':hashlib.sha256(binary).hexdigest(),'official_url':url})
    return p

def existing_xray():
    p=APP/'xray';manifest=APP/'binary.json'
    if not p.is_file() or not manifest.is_file():raise RuntimeError('本工具的Xray文件或校验清单缺失；refresh不会下载或替换它')
    try:meta=json.loads(manifest.read_text())
    except (OSError,json.JSONDecodeError):raise RuntimeError('本工具的Xray校验清单无效，停止') from None
    if meta.get('version')!=VERSION or hashlib.sha256(p.read_bytes()).hexdigest()!=meta.get('sha256'):
        raise RuntimeError('本工具的Xray校验不符；refresh不会替换它')
    return p

def curl_result(args,url):
    q=run(['curl','-q','--noproxy','','-sS','--retry','1','--retry-delay','1','--retry-all-errors','--connect-timeout','5','--max-time','12',*args,'-w','\n%{http_code}',url],timeout=32)
    body,_,code=q.stdout.decode(errors='replace').rpartition('\n')
    # No stderr: authentication details and implementation-specific errors stay private.
    return {'code':code,'rc':q.returncode,'body':body[:12000]}

def inspect_exit(args):
    tests=[curl_result(args,u) for u in ['https://www.gstatic.com/generate_204','https://www.apple.com/library/test/success.html','https://api.ipify.org','https://www.cloudflare.com/cdn-cgi/trace']]
    ipv4=None
    try:ipv4=str(ipaddress.ip_address(tests[2]['body'].strip())) if tests[2]['rc']==0 else None
    except ValueError:pass
    trace=dict(line.split('=',1) for line in tests[3]['body'].splitlines() if '=' in line)
    if ipv4 is None:
        try:ipv4=str(ipaddress.ip_address(trace.get('ip',''))) if tests[3]['rc']==0 else None
        except ValueError:pass
    https=any(t['rc']==0 and t['code'] in ('200','204') for t in tests[:2])
    return {'ok':https and ipv4 is not None,'https_ok':https,'ip':ipv4,'country':trace.get('loc','-'),'tests':tests}

def audit_upstreams(rows,interface,directory):
    def one(n):
        p=directory/(n['key']+'.curl')
        # curl config prevents user:password appearing in process arguments.
        address='['+n['server']+']' if ':' in n['server'] else n['server']
        write(p,'proxy = '+json.dumps('socks5h://'+address+':'+str(n['port']),ensure_ascii=False)+'\nproxy-user = '+json.dumps(n['username']+':'+n['password'],ensure_ascii=False)+'\ninterface = '+json.dumps(interface)+'\n')
        try:result=inspect_exit(['--config',str(p)])
        finally:p.unlink(missing_ok=True)
        result.update(name=n['name'],key=n['key']);print(('PASS ' if result['ok'] else 'SKIP ')+n['name']+' · '+str(result['ip'] or 'IP未确认'),flush=True);return result
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:return list(pool.map(one,rows))

def free_ports(count):
    sockets=[]
    try:
        for _ in range(count):
            sock=socket.socket();sockets.append(sock);sock.bind(('127.0.0.1',0))
        return [s.getsockname()[1] for s in sockets]
    finally:
        for s in sockets:s.close()

@contextlib.contextmanager
def process(xray,config,directory,label):
    file=directory/(label+'.json');write(file,config)
    q=run([str(xray),'run','-test','-config',str(file)])
    if q.returncode:raise RuntimeError('Xray配置校验失败：'+label+'（未上线）')
    log=directory/(label+'.log')
    with open(log,'wb') as f:
        proc=subprocess.Popen([str(xray),'run','-config',str(file)],stdout=f,stderr=f,start_new_session=True)
        try:
            time.sleep(1)
            if proc.poll() is not None:raise RuntimeError('隔离测试进程未能启动：'+label)
            yield proc
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=6)
                except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=5)

def probe(xray,rows,settings,remote,remote_port,directory,label):
    ports=free_ports(len(rows));cfg=client_config(rows,settings,remote,remote_port,ports)
    with process(xray,cfg,directory,label):
        def one(pair):
            n,p=pair;r=inspect_exit(['--proxy',f'socks5h://127.0.0.1:{p}']);r.update(name=n['name'],key=n['key']);return r
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:return list(pool.map(one,zip(rows,ports)))

def ask(label,default,validator):
    text=input(label+(f' [{default}]' if str(default) else '')+'：').strip() or str(default)
    return validator(text)

def settings(old,rows,xray):
    s=dict((old or {}).get('settings',{}))
    s['public_host']=ask('NAT公网IP或域名（不要填内网IP）',s.get('public_host',''),host)
    s['external_port']=ask('面板映射的公网TCP端口',s.get('external_port',''),port)
    s['internal_port']=ask('同一规则对应的本机内部TCP端口',s.get('internal_port',80),port)
    if s['internal_port']==22:raise ValueError('不能占用SSH内部22端口')
    s['interface']=ask('到供应商SOCKS5的网卡',s.get('interface','eth0'),lambda v:v)
    if not re.fullmatch(r'[A-Za-z0-9_.:-]{1,32}',s['interface']) or not Path('/sys/class/net',s['interface']).exists():raise ValueError('网卡不存在')
    s['sni']=ask('REALITY目标域名',s.get('sni','www.apple.com'),host)
    try:ipaddress.ip_address(s['sni']);raise ValueError('REALITY目标需要域名')
    except ValueError as exc:
        if str(exc)=='REALITY目标需要域名':raise
    if not old:
        q=run([str(xray),'x25519']);text=q.stdout.decode();parts=dict(re.findall(r'^([A-Za-z ()]+):\s*(\S+)\s*$',text,re.M))
        private=parts.get('PrivateKey',parts.get('Private key'));public=parts.get('Password (PublicKey)',parts.get('Password',parts.get('PublicKey',parts.get('Public key'))))
        if q.returncode or not key_valid(private) or not key_valid(public):raise RuntimeError('无法解析Xray生成的密钥，停止')
        s.update(private_key=private,public_key=public,short_id=secrets.token_hex(8),bridge_port=free_ports(1)[0])
    if not key_valid(s.get('private_key')) or not key_valid(s.get('public_key')):raise ValueError('已有密钥无效')
    return s

def init_system():
    if Path('/etc/alpine-release').exists() and shutil.which('rc-service'):return 'openrc'
    if Path('/run/systemd/system').is_dir() and shutil.which('systemctl'):return 'systemd'
    raise RuntimeError('需要Alpine/OpenRC或Debian/Ubuntu/systemd')

def service(action,init):
    q=run(['rc-service',SERVICE,action] if init=='openrc' else ['systemctl',action,SERVICE],timeout=55)
    if q.returncode:raise RuntimeError('服务操作失败：'+action)

def active(init):
    return run(['rc-service',SERVICE,'status'] if init=='openrc' else ['systemctl','is-active','--quiet',SERVICE]).returncode==0

def service_file(init):return Path('/etc/init.d/global-home-nodes') if init=='openrc' else Path('/etc/systemd/system/global-home-nodes.service')

def install_service(init):
    target=service_file(init)
    if init=='openrc':
        text='''#!/sbin/openrc-run
description="Global Home independent exits"
supervisor="supervise-daemon"
command="/opt/global-home-nodes/xray"
command_args="run -config /etc/global-home-nodes/current/config.json"
respawn_delay=5
respawn_max=0
respawn_period=60
output_log="/var/log/global-home-nodes.log"
error_log="/var/log/global-home-nodes.log"
depend() { need net; }
'''
    else:
        text='''[Unit]
Description=Global Home independent VLESS exits
After=network-online.target
Wants=network-online.target
[Service]
ExecStart=/opt/global-home-nodes/xray run -config /etc/global-home-nodes/current/config.json
Restart=on-failure
RestartSec=5
UMask=0077
PrivateTmp=true
ProtectHome=true
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
'''
    write(target,text);target.chmod(0o755 if init=='openrc' else 0o644)
    if init=='systemd':
        if run(['systemctl','daemon-reload']).returncode:raise RuntimeError('systemd重载失败')

def set_current(directory):
    tmp=ROOT/'current.next'
    if tmp.exists() or tmp.is_symlink():tmp.unlink()
    tmp.symlink_to(directory.resolve().relative_to(ROOT.resolve()));os.replace(tmp,ROOT/'current')

def ensure_free(port_value):
    with socket.socket() as s:
        try:s.bind(('0.0.0.0',port_value))
        except OSError:raise RuntimeError(f'内部端口 {port_value} 已占用；不会覆盖现有服务，请另建NAT映射') from None

def deploy(args):
    init=init_system();current=ROOT/'current';old=None;prior=None
    if current.is_symlink():
        prior=current.resolve()
        if prior.parent!=(ROOT/'generations').resolve():raise RuntimeError('异常current链接')
        old=json.loads((prior/'state.private.json').read_text())
    elif current.exists():raise RuntimeError('current不是本工具的代际符号链接，拒绝覆盖')
    if args.action=='refresh' and not old:raise RuntimeError('尚无本工具节点配置；首次安装请运行 global-home-nodes deploy')
    if args.action=='deploy' and old:raise RuntimeError('已有节点配置；读取出口并更新节点请运行 global-home-nodes refresh')
    if service_file(init).exists() and not old:raise RuntimeError('发现同名服务，不覆盖；先检查原安装状态')
    was_active=active(init) if old else False
    xray=existing_xray() if args.action=='refresh' else ensure_xray();rows=extract(args.import_json)
    # Refresh reuses all stable transport settings; it changes only the authorized exit set.
    s=dict(old['settings']) if args.action=='refresh' else settings(None,rows,xray)
    if not old or old['settings']['internal_port']!=s['internal_port']:ensure_free(s['internal_port'])
    if not old:ensure_free(s['bridge_port'])
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+secrets.token_hex(3)
    generation=ROOT/'generations'/stamp;generation.mkdir(parents=True,mode=0o700)
    with tempfile.TemporaryDirectory(prefix='home-nodes-test-',dir='/tmp') as work:
        temp=Path(work)
        print('检测授权SOCKS5（多站HTTPS和出口IP）…',flush=True)
        audit=audit_upstreams(rows,s['interface'],temp);write(generation/'upstream-audit.json',audit)
        accepted={r['key'] for r in audit if r['ok']};selected=credentials([n for n in rows if n['key'] in accepted],old)
        if not selected:raise RuntimeError('没有满足HTTPS及IP确认要求的出口；原服务未改')
        skipped=[r['name'] for r in audit if not r['ok']]
        if skipped:print('本轮不发布：'+'、'.join(skipped)+'（含HTTPS成功但IP未确认项；不等同证明失效）',flush=True)
        write(generation/'authorized-backends.private.json',rows)
        trial=dict(s);trial['internal_port'],trial['bridge_port']=free_ports(2)
        print('使用本机回环端口验证完整 VLESS/REALITY → SOCKS5 链路…',flush=True)
        with process(xray,server_config(selected,trial,listen='127.0.0.1'),temp,'candidate-server'):
            local=probe(xray,selected,trial,'127.0.0.1',trial['internal_port'],temp,'candidate-client')
        write(generation/'local-preflight.json',local)
        if not all(r['ok'] for r in local):raise RuntimeError('候选完整链路未全部通过，原服务未改；检查REALITY握手出口或目标域名')
        cfg=server_config(selected,s);write(generation/'config.json',cfg)
        write(generation/'state.private.json',{'settings':s,'nodes':selected,'created_utc':stamp,'version':1})
        q=run([str(xray),'run','-test','-config',str(generation/'config.json')])
        if q.returncode:raise RuntimeError('最终配置语法未通过，未上线')
        print(f'准备发布 {len(selected)} 个独立节点：公网 {s["public_host"]}:{s["external_port"]} → 内部TCP {s["internal_port"]}。',flush=True)
        print('其他代理/TG不会被改动；更新会移除本轮未通过的旧节点，旧代配置保留。',flush=True)
        if input('确认面板映射正确并上线，输入 DEPLOY：').strip()!='DEPLOY':raise RuntimeError('已取消，原服务未改')
        old_service=service_file(init).read_bytes() if service_file(init).exists() else None
        if old_service:write(generation/'service.before',old_service)
        switched=False
        try:
            if was_active:service('stop',init)
            ensure_free(s['internal_port']);ensure_free(s['bridge_port'])
            set_current(generation);switched=True;install_service(init);service('start',init)
            time.sleep(1)
            if not active(init):raise RuntimeError('新服务未保持运行')
            final=probe(xray,selected,s,'127.0.0.1',s['internal_port'],temp,'deployed-client');write(generation/'local-deployed.json',final)
            if not all(r['ok'] for r in final):raise RuntimeError('上线后本机完整链路检测失败')
            # NAT loopback can fail even when inbound forwarding works. Label separately.
            print('额外尝试从本机回连公网映射；不支持NAT回环时需要外部复核…',flush=True)
            public=probe(xray,selected,s,s['public_host'],s['external_port'],temp,'public-client');write(generation/'public-loopback.json',public)
            pubok=all(r['ok'] for r in public)
            for name,data in exports(selected,s).items():write(generation/name,data)
            report={'tool_version':TOOL_VERSION,'count':len(selected),'skipped':skipped,'path':'public NAT -> dedicated VLESS+REALITY -> per-user SOCKS5','local_chain_passed':True,'public_nat_loopback_passed':pubok,'external_vantage_verified':False,'handshake_dependency':selected[0]['name'],'ip_quality_or_residential_verified':False,'udp':False,'xray_version':VERSION,'current':stamp,'previous':prior.name if prior else None}
            write(generation/'report.json',report)
            write(generation/'检测结果.txt',f'已发布 {len(selected)} 个独立节点。\n本机完整VLESS/REALITY→SOCKS5测试通过。\n公网NAT回环测试：{"通过（仍非外部视角）" if pubok else "未通过，可能不支持NAT回环，须外部验证映射"}。\n非公网订阅服务；输出文件权限0600。\nREALITY握手依赖：{selected[0]["name"]}，该出口故障可能影响所有节点握手。\n未测UDP，未认证住宅属性。动态IP随时可能变化。\n未通过或IP未确认：'+('、'.join(skipped) or '无')+'\n')
            q=run(['rc-update','add',SERVICE,'default'] if init=='openrc' else ['systemctl','enable',SERVICE])
            if q.returncode:raise RuntimeError('服务开机注册失败')
            print('完成。本地文件（均包含认证信息，请妥善保管）：\n'+str(current/'vless.txt')+'\n'+str(current/'clash.yaml')+'\n'+str(current/'socks5-private.txt'),flush=True)
            print('公网映射回环测试通过。' if pubok else '注意：公网映射尚未验证成功；请从外部客户端测试，不能仅凭本机测试宣布公网可用。',flush=True)
        except BaseException:
            if switched:
                try:service('stop',init)
                except Exception:pass
                if prior:
                    set_current(prior)
                    if old_service:write(service_file(init),old_service);service_file(init).chmod(0o755 if init=='openrc' else 0o644)
                    if init=='systemd':run(['systemctl','daemon-reload'])
                    if was_active:service('start',init)
                    print('失败，已回滚原代配置。',flush=True)
                else:
                    run(['rc-update','del',SERVICE,'default'] if init=='openrc' else ['systemctl','disable',SERVICE])
                    current.unlink(missing_ok=True)
                    path=service_file(init)
                    if path.exists():path.rename(generation/'failed-service')
                    if init=='systemd':run(['systemctl','daemon-reload'])
                    print('首次部署失败，新服务已停止；候选代保留于私有目录。',flush=True)
            elif was_active and not active(init):service('start',init)
            raise

def uninstall():
    if not (APP/'INSTALLER-MARKER').is_file():raise RuntimeError('不是本安装器，拒绝卸载')
    if input('仅移除本工具独立节点服务，不动proxy/TG。输入 REMOVE：').strip()!='REMOVE':return
    init=init_system()
    if active(init):service('stop',init)
    run(['rc-update','del',SERVICE,'default'] if init=='openrc' else ['systemctl','disable',SERVICE])
    dest=Path('/root/global-home-nodes-retired')/(datetime.datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(3));dest.mkdir(parents=True,mode=0o700)
    path=service_file(init)
    if path.exists():shutil.move(str(path),dest/'service')
    gl=Path('/usr/local/bin/gl')
    if gl.is_symlink() and os.readlink(gl)==str(APP/'gl'):gl.unlink()
    shutil.move(str(ROOT),dest/'config');shutil.move(str(APP),dest/'app')
    if init=='systemd':run(['systemctl','daemon-reload'])
    print('已移入可恢复私有备份（含密钥）：'+str(dest))

def relay_lines():
    doc=read_runtime_export(ROOT)
    print('\n========== Global家宽线路（Xray当前配置映射） ==========')
    for row in doc['exits']:
        expected=row.get('expected_exit_ip') or '未记录'
        print(f"{row['name']} | {row['id']} | UUID={row['uuid']} | email={row['email']} | {row['outbound_tag']} → {row['socks5']['server']}:{row['socks5']['port']} | 上次出口记录={expected}")
    for row in doc['anomalies']:
        print(f"异常：{row['name']} | {row['id']} | {row['reason']}（未导出为正常线路）")

def relay_public_parameters():
    profile=read_runtime_export(ROOT)['profile']
    print('\n========== Global Reality公共参数 ==========')
    for key,label in [('server','公网IP/域名'),('public_port','公网映射端口'),('network','Network'),('security','Security'),('sni','SNI'),('fingerprint','Fingerprint'),('flow','Flow'),('public_key','Public Key'),('short_id','Short ID')]:
        print(f'{label}：{profile[key]}')

def relay_export():
    path=export_from_runtime(ROOT,service_active=active(init_system()))
    doc=json.loads(path.read_text(encoding='utf-8'))
    print('已重新读取当前Global Home运行代并导出：'+str(path))
    print(f"可导入线路：{len(doc['exits'])}；异常线路：{len(doc['anomalies'])}")
    if doc['anomalies']:
        for row in doc['anomalies']:
            print(f"未导出：{row['name']} | {row['reason']}")
    print('文件权限：600；仅包含Global VLESS Reality公共参数和有效线路，不包含私钥或SOCKS密码。')

def relay_route_check():
    doc=read_runtime_export(ROOT)
    print('\n========== UUID → email → route → outbound → SOCKS5 =========')
    for row in doc['exits']:
        print(f"有效：{row['name']} | {row['uuid']} → {row['email']} → {row['outbound_tag']} → {row['socks5']['server']}:{row['socks5']['port']}")
    for row in doc['anomalies']:
        print(f"异常：{row['name']} | {row['reason']}；不会作为正常线路导出")
    print(f"有效线路 {len(doc['exits'])} 条；异常 {len(doc['anomalies'])} 条。")

def relay_outbound_status():
    init=init_system()
    if not active(init):raise RuntimeError('Global Home Xray服务未运行；无法确认当前线路状态')
    _config,state,_prior_audit=load_runtime_generation(ROOT)
    rows=state.get('nodes')
    settings=state.get('settings')
    if not isinstance(rows,list) or not isinstance(settings,dict):raise RuntimeError('当前运行代缺少SOCKS线路元数据')
    with tempfile.TemporaryDirectory(prefix='home-nodes-relay-check-',dir='/tmp') as temp:
        results=audit_upstreams(rows,settings['interface'],Path(temp))
    print('\n========== SOCKS出站与公网出口检测（本次实时检查） ==========')
    for row in results:
        print(f"{'PASS' if row['ok'] else '未通过'}：{row['name']} | SOCKS/HTTPS={'通过' if row['https_ok'] else '未通过'} | 出口IP={row['ip'] or '未确认'} | 国家={row['country']}")
    print('此项检测只确认Global本机到SOCKS5及公网出口；它不代表狗妈到Global的Reality握手状态。')

def relay_status():
    p=ROOT/'current/report.json'
    print(p.read_text() if p.exists() else '尚无成功部署记录')
    print('service_active='+str(active(init_system())))

def relay_menu():
    while True:
        print('\n========== Global Home 统一管理 ==========')
        print('1）显示全部家宽线路')
        print('2）显示 Reality 公共参数')
        print('3）导出狗妈中转 JSON')
        print('4）检查家宽 UUID 与 Xray 路由对应关系')
        print('5）检查家宽出站状态')
        print('6）查看 Global Home 运行状态')
        print('7）首次部署 Global Home')
        print('8）读取供应商 proxy 最新线路并更新')
        print('9）从授权 JSON 更新线路')
        print('10）检查管理程序更新')
        print('11）安装管理程序更新')
        print('12）卸载 Global Home')
        print('0）返回')
        choice=input('请选择：').strip()
        if choice=='0':return
        if choice=='1':relay_lines()
        elif choice=='2':relay_public_parameters()
        elif choice=='3':relay_export()
        elif choice=='4':relay_route_check()
        elif choice=='5':relay_outbound_status()
        elif choice=='6':relay_status()
        elif choice=='7':deploy(argparse.Namespace(action='deploy',import_json=None))
        elif choice=='8':deploy(argparse.Namespace(action='refresh',import_json=None))
        elif choice=='9':
            path=input('请输入授权JSON文件路径（留空取消）：').strip()
            if path:deploy(argparse.Namespace(action='refresh',import_json=path))
            else:print('已取消线路更新。')
        elif choice=='10':update_manager(check_only=True)
        elif choice=='11':
            update_manager(check_only=False)
            return
        elif choice=='12':
            uninstall()
            return
        else:print('无效选项。')

def main():
    os.umask(0o077)
    def interrupted(signum,frame):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGHUP,interrupted)
    if os.geteuid()!=0:raise RuntimeError('需要root')
    parser=argparse.ArgumentParser(description='Global Home multi-exit manager')
    parser.add_argument('action',choices=['deploy','refresh','status','update','uninstall','export-relay','menu'],nargs='?',default='deploy')
    parser.add_argument('--import-json')
    parser.add_argument('--check-only',action='store_true',help='only check for management-program updates')
    args=parser.parse_args()
    if args.check_only and args.action!='update':raise RuntimeError('--check-only 只能用于 update')
    if not APP.is_dir():raise RuntimeError('Global Home 尚未安装')
    if args.action=='update' and args.import_json:raise RuntimeError('update 不接受 --import-json')
    with open(APP/'.operation.lock','w') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise RuntimeError('其他管理操作正在进行') from None
        if args.action=='update':
            update_manager(check_only=args.check_only)
            return
        if args.action=='export-relay':
            if args.import_json:raise RuntimeError('export-relay 不接受 --import-json')
            relay_export()
            return
        if args.action=='menu':
            if args.import_json:raise RuntimeError('menu 不接受 --import-json')
            relay_menu()
            return
        ROOT.mkdir(mode=0o700,parents=True,exist_ok=True)
        if args.action=='uninstall':uninstall()
        elif args.action=='status':relay_status()
        else:deploy(args)

if __name__=='__main__':
    try:main()
    except (Exception,KeyboardInterrupt) as exc:
        # Do not print tracebacks, URLs with auth, or supplier responses.
        message=str(exc) if isinstance(exc,(ValueError,RuntimeError)) else type(exc).__name__
        print('未完成：'+message,file=sys.stderr);sys.exit(1)
