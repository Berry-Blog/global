# Global Home v2.1.2 使用说明

## 安装

```sh
sh global-home-nodes-install-v2.1.2.sh --verify
sh global-home-nodes-install-v2.1.2.sh
```

已安装旧版的机器可运行 v2.1.2 安装器更新管理程序。

## 统一交互菜单

运行 `gl` 打开所有 Global Home 功能：

```sh
gl
```

菜单包含线路查看、Reality 公共参数、狗妈 JSON 导出、线路映射检查、单次出站检查、运行状态、首次部署、线路更新、管理程序更新检查/安装和卸载。首次部署可选择读取供应商 `proxy` 菜单或导入授权 JSON。

选择“读取供应商 proxy 最新线路并更新”会在操作时只读本机供应商 `proxy` 出口菜单，不会切换供应商当前线路。读取前需要确认授权；读取后 Global Home 会执行线路检测，只有再次确认才会应用更新。也可选择从授权 JSON 文件更新。

供应商同步和出站检查都是手动触发，不会后台监控。首次部署只用于尚未部署的机器；已部署线路通过线路更新选项维护。管理程序安装更新后会退出菜单，重新运行 `gl` 使用新版本。

## 命令行兼容入口

```sh
global-home-nodes status
global-home-nodes refresh
global-home-nodes update
global-home-nodes update --check-only
global-home-nodes refresh --import-json /root/my-authorized-exits.json
global-home-nodes uninstall
gl export-relay
```
