#!/usr/bin/env python3
"""Code-only updater. It cannot read or write /etc/global-home-nodes state."""
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import urllib.parse
import urllib.request
import zipfile

APP = Path("/opt/global-home-nodes")
RAW_BASE = "https://raw.githubusercontent.com/Berry-Blog/global/main/"
MANIFEST_URL = RAW_BASE + "update/manifest.json"
MAX_MANIFEST = 32 * 1024
MAX_ARCHIVE = 16 * 1024 * 1024
MAX_MEMBER = 4 * 1024 * 1024
UPDATE_FILES = (
    "VERSION.json",
    "core.py",
    "deploy.py",
    "relay_export.py",
    "lazycat_adapter.py",
    "update_manager.py",
    "extract.exp",
    "gl",
)
PACKAGE_FILES = frozenset(
    {
        "VERSION.json",
        "core.py",
        "deploy.py",
        "relay_export.py",
        "lazycat_adapter.py",
        "update_manager.py",
        "extract.exp",
        "gl",
        "install.sh",
        "README.md",
        "LICENSE",
        "release.json",
        "SHA256SUMS",
    }
)


def _version(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", value):
        raise ValueError("更新清单中的版本号格式无效")
    return tuple(int(part) for part in value.split("."))


def _read_url(url, maximum):
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Global-Home-Updater/2.1.2", "Accept": "application/json, application/zip, */*"},
    )
    try:
        with urllib.request.urlopen(request, timeout=25) as response:
            final = urllib.parse.urlparse(response.geturl())
            if final.scheme != "https" or final.hostname not in ("raw.githubusercontent.com",):
                raise RuntimeError("更新地址跳转到非预期站点，已停止")
            length = response.headers.get("Content-Length")
            if length and int(length) > maximum:
                raise RuntimeError("更新文件超过大小限制")
            body = response.read(maximum + 1)
    except (OSError, ValueError) as exc:
        raise RuntimeError("无法从 GitHub 获取更新清单或源码") from None
    if len(body) > maximum:
        raise RuntimeError("更新文件超过大小限制")
    return body


def _manifest():
    raw = _read_url(MANIFEST_URL, MAX_MANIFEST)
    try:
        doc = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise RuntimeError("GitHub 更新清单不是有效JSON") from None
    if not isinstance(doc, dict) or doc.get("schema") != 1 or doc.get("tool") != "global-home-nodes":
        raise RuntimeError("GitHub 更新清单格式不受支持")
    version = doc.get("version")
    adapter = doc.get("adapter_version")
    _version(version)
    _version(adapter)
    archive_path = doc.get("archive_path")
    if not isinstance(archive_path, str) or not re.fullmatch(r"[A-Za-z0-9._/-]+", archive_path):
        raise RuntimeError("更新清单中的源码路径无效")
    if archive_path.startswith("/") or ".." in PurePosixPath(archive_path).parts:
        raise RuntimeError("更新清单中的源码路径无效")
    digest = doc.get("archive_sha256")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise RuntimeError("更新清单中的SHA256格式无效")
    return doc


def _local_versions():
    try:
        data = json.loads((APP / "VERSION.json").read_text(encoding="utf-8"))
        version, adapter = data.get("version"), data.get("adapter_version")
    except (OSError, json.JSONDecodeError, AttributeError):
        # v1 installations have no version file; their application marker is the migration signal.
        try:
            marker = (APP / "INSTALLER-MARKER").read_text(encoding="utf-8").strip()
        except OSError:
            raise RuntimeError("找不到本工具安装标记，拒绝更新") from None
        if marker == "global-home-nodes-v1":
            return (1, 0, 0), (0, 0, 0), "1.0.0", "0.0.0"
        raise RuntimeError("本地版本文件无效，拒绝更新") from None
    return _version(version), _version(adapter), version, adapter


def _newer(remote, local):
    return _version(remote["version"]) > local[0] or (
        _version(remote["version"]) == local[0]
        and _version(remote["adapter_version"]) > local[1]
    )


def _archive_files(raw, release):
    if hashlib.sha256(raw).hexdigest() != release["archive_sha256"]:
        raise RuntimeError("源码ZIP的SHA256不匹配，未更新")
    expected = {"global-home-nodes/" + name for name in PACKAGE_FILES}
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos = archive.infolist()
            names = [info.filename for info in infos]
            if len(names) != len(set(names)) or set(names) != expected:
                raise RuntimeError("源码ZIP文件清单不符合预期，未更新")
            files = {}
            for info in infos:
                path = PurePosixPath(info.filename)
                mode = (info.external_attr >> 16) & 0xFFFF
                if path.is_absolute() or ".." in path.parts or "\\" in info.filename:
                    raise RuntimeError("源码ZIP包含不安全路径，未更新")
                if stat.S_ISLNK(mode) or info.flag_bits & 1:
                    raise RuntimeError("源码ZIP包含链接或加密文件，未更新")
                if info.file_size > MAX_MEMBER or info.file_size != info.compress_size and info.file_size > MAX_MEMBER:
                    raise RuntimeError("源码ZIP单文件超过大小限制")
                files[PurePosixPath(info.filename).name] = archive.read(info)
    except (zipfile.BadZipFile, OSError, RuntimeError):
        raise RuntimeError("源码ZIP损坏或不符合安全格式，未更新") from None

    try:
        release_meta = json.loads(files["release.json"].decode("utf-8"))
        version_doc = json.loads(files["VERSION.json"].decode("utf-8"))
    except (KeyError, UnicodeDecodeError, json.JSONDecodeError):
        raise RuntimeError("源码包缺少版本元数据") from None
    if (
        release_meta.get("tool") != "global-home-nodes"
        or release_meta.get("version") != release["version"]
        or release_meta.get("adapter_version") != release["adapter_version"]
        or version_doc.get("version") != release["version"]
        or version_doc.get("adapter_version") != release["adapter_version"]
    ):
        raise RuntimeError("源码包版本与更新清单不一致")

    good = set()
    for line in files["SHA256SUMS"].decode("utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64})  ([A-Za-z0-9._-]+)", line)
        if not match:
            raise RuntimeError("源码包SHA256清单格式无效")
        digest, name = match.groups()
        if name not in PACKAGE_FILES - {"SHA256SUMS"} or name not in files:
            raise RuntimeError("源码包SHA256清单包含未知文件")
        if hashlib.sha256(files[name]).hexdigest() != digest:
            raise RuntimeError("源码包内部校验失败：" + name)
        good.add(name)
    if good != PACKAGE_FILES - {"SHA256SUMS"}:
        raise RuntimeError("源码包SHA256清单不完整")
    return files


def _safe_app():
    if not APP.is_dir() or APP.is_symlink():
        raise RuntimeError("程序目录不存在或不是普通目录，拒绝更新")
    try:
        marker = (APP / "INSTALLER-MARKER").read_text(encoding="utf-8").strip()
    except OSError:
        raise RuntimeError("找不到本工具安装标记，拒绝更新") from None
    if marker not in ("global-home-nodes-v1", "global-home-nodes-v2"):
        raise RuntimeError("安装标记不属于本工具，拒绝更新")


def _check_gl_link():
    path = Path("/usr/local/bin/gl")
    if path.exists() or path.is_symlink():
        if not path.is_symlink() or os.readlink(path) != str(APP / "gl"):
            raise RuntimeError("/usr/local/bin/gl 已被其他文件占用，拒绝覆盖")
    return path


def _ensure_gl_link():
    path = _check_gl_link()
    if not (APP / "gl").is_file():
        raise RuntimeError("更新包缺少gl快捷命令")
    if path.is_symlink():
        return
    temp = path.with_name(".gl." + str(os.getpid()) + ".next")
    try:
        os.symlink(str(APP / "gl"), temp)
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def update(check_only=False):
    """Update management code and the adapter only; node state is never opened."""
    _safe_app()
    gl_link = _check_gl_link()
    local = _local_versions()
    release = _manifest()
    if not _newer(release, local):
        if (APP / "gl").is_file():
            _ensure_gl_link()
        print(f"管理程序已是最新版本（{local[2]}，LazyCat适配器 {local[3]}）。")
        return

    print(
        f"发现管理程序 {release['version']} / LazyCat适配器 {release['adapter_version']}；"
        "本次更新只替换 /opt/global-home-nodes 中的管理代码和适配器。"
    )
    print("现有节点配置、UUID、Reality密钥、端口、Xray二进制和sing-box均不读取或修改。")
    if check_only:
        print("检查完成；没有写入文件。")
        return

    archive_url = urllib.parse.urljoin(RAW_BASE, release["archive_path"])
    body = _read_url(archive_url, MAX_ARCHIVE)
    files = _archive_files(body, release)

    backup_root = Path("/root/global-home-nodes-code-backups")
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = backup_root / (stamp + "-" + os.urandom(3).hex() + "-update")
    backup.mkdir(mode=0o700, parents=True, exist_ok=False)
    os.chmod(backup_root, 0o700)
    os.chmod(backup, 0o700)
    stage = APP / (".update-stage-" + str(os.getpid()) + "-" + os.urandom(3).hex())
    stage.mkdir(mode=0o700, exist_ok=False)
    originals = {}
    changed = []
    gl_existed = gl_link.is_symlink()
    try:
        for name in UPDATE_FILES:
            path = APP / name
            if path.exists() and (path.is_symlink() or not path.is_file()):
                raise RuntimeError("程序文件类型异常，拒绝覆盖：" + name)
            originals[name] = path.read_bytes() if path.exists() else None
            if originals[name] is not None:
                (backup / name).write_bytes(originals[name])
                os.chmod(backup / name, 0o600)
            (stage / name).write_bytes(files[name])
            os.chmod(stage / name, 0o700 if name.endswith((".py", ".exp")) or name == "gl" else 0o600)

        for name in UPDATE_FILES:
            os.replace(stage / name, APP / name)
            os.chmod(APP / name, 0o700 if name.endswith((".py", ".exp")) or name == "gl" else 0o600)
            changed.append(name)
        _ensure_gl_link()
    except Exception:
        if not gl_existed and gl_link.is_symlink() and os.readlink(gl_link) == str(APP / "gl"):
            gl_link.unlink()
        for name in reversed(changed):
            target = APP / name
            original = originals[name]
            if original is None:
                target.unlink(missing_ok=True)
            else:
                rollback = stage / (name + ".rollback")
                rollback.write_bytes(original)
                os.chmod(rollback, 0o700 if name.endswith((".py", ".exp")) or name == "gl" else 0o600)
                os.replace(rollback, target)
        raise RuntimeError("代码更新失败，管理程序文件已回滚；节点配置未触及") from None
    finally:
        shutil.rmtree(stage, ignore_errors=True)

    print(f"管理程序与LazyCat适配器已更新；代码备份保存在 {backup}。")
    print("节点服务没有重启；如需重新读取出口，请单独运行 global-home-nodes refresh。")
