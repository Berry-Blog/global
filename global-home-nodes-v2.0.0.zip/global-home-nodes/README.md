# Global Home 多家宽管理工具 v2.0.0

在你有权管理的 LazyCat Global 前置机上，为已授权的 SOCKS5 家宽出口生成独立 VLESS + REALITY + Vision 节点。每个出口使用独立 UUID；业务流量按出口路由。本工具保留自己的 Xray 服务，和系统现有 sing-box 分开管理。

## 两个独立操作

```sh
global-home-nodes update
```

只更新 `/opt/global-home-nodes` 中的管理程序和 LazyCat 适配器。更新器读取公开的 GitHub 更新清单与源码 ZIP，校验 SHA256 和包内文件清单，再替换程序文件；只备份管理代码。它不读取 `/etc/global-home-nodes`，不改节点配置、UUID、REALITY 密钥、端口、Xray 二进制、systemd/OpenRC 服务或现有 sing-box，也不重启节点服务。首次使用可先检查：

```sh
global-home-nodes update --check-only
```

仓库发布更新时，需要同时提供 `update/manifest.json` 和清单指向的源码 ZIP。找不到清单或校验失败时，更新会停止且不写入节点配置。

```sh
global-home-nodes refresh
```

重新读取你已授权的出口、检测可用性并更新本工具自己的节点配置。现有 REALITY 密钥、短 ID、公网/内部端口和网卡设置会复用；同名出口保留原 UUID。出口改名视为新出口。刷新前会校验候选配置，失败时保留当前配置。未通过检测的出口不会发布到新配置中。

刷新时默认通过 LazyCat 的只读 `proxy` 菜单读取出口。如果供应商提供授权 JSON，也可以使用：

```sh
global-home-nodes refresh --import-json /root/my-authorized-exits.json
```

JSON 格式：

```json
{
  "listen_ip": "10.0.0.1",
  "nodes": [
    {
      "info": "日本-示例出口",
      "port": 5001,
      "socks_user": "YOUR_USER",
      "socks_pass": "YOUR_PASSWORD"
    }
  ]
}
```

## 安装和迁移

新机器以 root 执行：

```sh
sh global-home-nodes-install-v2.0.0.sh
```

已安装 v1 且 `/etc/global-home-nodes/current` 存在时，安装器只升级管理程序和适配器，不会自动刷新出口或重新部署节点。迁移后如需读取新出口，再单独运行 `global-home-nodes refresh`。

安装器使用独立 Xray VLESS/REALITY 服务，不接管现有端口或 sing-box。初次部署需要你输入公网映射、内部端口和网卡，并在最后输入 `DEPLOY` 确认。系统只支持 Alpine/OpenRC 或 Debian/Ubuntu/systemd，架构为 x86_64/aarch64。

## 其他命令

```sh
global-home-nodes deploy
global-home-nodes status
global-home-nodes uninstall
```

`deploy` 只用于首次部署；已有配置时请用 `refresh`。卸载会要求输入 `REMOVE`，只停用本工具自己的服务并将本工具文件移入 root 私有归档，不会删除供应商 `proxy`、现有 sing-box 或 TG 服务。

## 本地输出

- `/etc/global-home-nodes/current/vless.txt`：独立节点链接。
- `/etc/global-home-nodes/current/clash.yaml`：Mihomo 导入配置。
- `/etc/global-home-nodes/current/shadowrocket-base64.txt`：节点集合文本，不是在线订阅。
- `/etc/global-home-nodes/current/socks5-private.txt`：含认证信息的后端列表，仅供管理员保管。
- `/etc/global-home-nodes/current/report.json`：最近一次部署/刷新摘要。

配置目录为 root 私有权限。不要公开分享 `/etc/global-home-nodes`、备份或含 SOCKS5 认证信息的导出文件。

## LazyCat 适配器

LazyCat 读取逻辑单独放在 `lazycat_adapter.py` 和 `extract.exp`。供应商菜单变化时，可以通过 `global-home-nodes update` 单独替换管理程序与适配器；若新菜单格式未识别，当前版本会停止读取，并保留显式授权 JSON 导入方式，不会猜测认证字段或自动切换出口。

## 网络边界

- 不创建公开在线订阅，不配置通用中转，不自动添加防火墙规则。
- 仅在你有权管理的机器和出口上使用；不绕过供应商认证或系统权限限制。
- REALITY 握手桥只监听本机回环地址；本机 NAT 回环检测不等于外网映射验证。
- TCP-only；不承诺 UDP/XUDP，也不认证出口的住宅属性。
- 更新与节点刷新分开执行；更新器下载源码仅访问 GitHub 的 HTTPS 原始文件地址。

MIT License。
