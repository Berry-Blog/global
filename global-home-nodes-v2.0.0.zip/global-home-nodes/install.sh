#!/bin/sh
set -eu
umask 077

[ "$(id -u)" -eq 0 ] || { echo '请用root运行。'; exit 1; }
SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
APP=/opt/global-home-nodes
CONF=/etc/global-home-nodes
CLI=/usr/local/bin/global-home-nodes
MARKER=global-home-nodes-v2
OLD_MARKER=$(cat "$APP/INSTALLER-MARKER" 2>/dev/null || true)

echo 'Global Home 多家宽管理工具 v2.0.0'
echo 'update 只更新管理程序和 LazyCat 适配器；refresh 才会读取出口并更新本工具自己的节点配置。'
echo '本工具使用独立 Xray 服务，不改动系统现有 sing-box、proxy 或 TG 服务。'

if [ -e "$CLI" ] && ! grep -q 'GLOBAL_HOME_NODES_CLI_V2' "$CLI" 2>/dev/null; then
  echo "发现已有命令 $CLI，且不是本工具创建的；拒绝覆盖。" >&2
  exit 1
fi

if [ -e "$APP" ]; then
  case "$OLD_MARKER" in
    global-home-nodes-v1|global-home-nodes-v2) ;;
    *) echo '发现同名目录但没有本工具安装标记，停止。' >&2; exit 1 ;;
  esac
  [ -d "$APP" ] || { echo '程序目录不是普通目录，停止。' >&2; exit 1; }
  if [ -e "$CONF/current" ] && [ ! -L "$CONF/current" ]; then
    echo '配置 current 不是本工具的代际链接，停止。' >&2
    exit 1
  fi
elif [ -e "$CONF" ]; then
  echo '发现节点配置目录但没有本工具程序目录；拒绝接管。' >&2
  exit 1
else
  for path in /etc/init.d/global-home-nodes /etc/systemd/system/global-home-nodes.service; do
    [ ! -e "$path" ] || { echo "发现已有服务 $path，停止。" >&2; exit 1; }
  done
fi

if [ -f /etc/alpine-release ]; then
  apk add --no-cache python3 curl expect strace coreutils ca-certificates
elif command -v apt-get >/dev/null 2>&1 && command -v systemctl >/dev/null 2>&1; then
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3 curl expect strace coreutils ca-certificates
else
  echo '仅支持 Alpine/OpenRC 或 Debian/Ubuntu/systemd。' >&2
  exit 1
fi
for cmd in python3 curl expect strace sha256sum; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "缺少依赖：$cmd" >&2; exit 1; }
done

if [ -d "$APP" ]; then
  backup=/root/global-home-nodes-code-backups/$(date +%Y%m%d-%H%M%S)-v2
  mkdir -p "$backup"
  chmod 700 /root/global-home-nodes-code-backups "$backup"
  for file in core.py deploy.py lazycat_adapter.py extract.exp VERSION.json; do
    [ ! -f "$APP/$file" ] || cp -p "$APP/$file" "$backup/$file"
  done
  echo "旧管理程序备份：$backup"
fi

mkdir -p "$APP" "$CONF"
chmod 700 "$APP" "$CONF"
chown root:root "$APP" "$CONF"
for file in core.py deploy.py lazycat_adapter.py extract.exp VERSION.json; do
  install -o root -g root -m 700 "$SOURCE/$file" "$APP/$file"
done
printf '%s\n' "$MARKER" > "$APP/INSTALLER-MARKER"
chmod 600 "$APP/INSTALLER-MARKER"

tmp_cli=$(mktemp /usr/local/bin/.global-home-nodes.XXXXXX)
trap 'rm -f "$tmp_cli"' EXIT HUP INT TERM
cat > "$tmp_cli" <<'EOF'
#!/bin/sh
# GLOBAL_HOME_NODES_CLI_V2
exec python3 /opt/global-home-nodes/deploy.py "$@"
EOF
install -o root -g root -m 755 "$tmp_cli" "$CLI"
rm -f "$tmp_cli"
trap - EXIT HUP INT TERM

if [ -L "$CONF/current" ]; then
  echo '管理程序已升级。现有节点、UUID、Reality 密钥、端口和服务配置均保留；需要更新出口时另行运行：'
  echo '  global-home-nodes refresh'
  exit 0
fi

exec python3 "$APP/deploy.py" deploy "$@"
