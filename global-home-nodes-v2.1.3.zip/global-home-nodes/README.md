# Global Home v2.1.3

本源码包提供 Global Home 管理工具。更新管理程序只替换程序文件，不重建 `/etc/global-home-nodes` 中的线路数据，也不更改 Xray 服务。

v2.1.3 修复导出器未识别数字开头线路 key 的问题。升级后使用 `gl` 选择“导出狗妈中转 JSON”即可重新生成导出文件。
