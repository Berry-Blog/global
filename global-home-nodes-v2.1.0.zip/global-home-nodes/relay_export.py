#!/usr/bin/env python3
"""Build a least-privilege Dogma relay document from the current Xray generation."""
from __future__ import annotations

import datetime as _dt
import ipaddress
import json
import os
from pathlib import Path
import re
import tempfile


SCHEMA_VERSION = 1
KIND = "global-home-dogma-relay"
DEFAULT_EXPORT_ROOT = Path("/etc/global-home-nodes/exports")
_ID_RE = re.compile(r"^[a-z][a-z0-9-]{1,31}$")


def _host(value: object, label: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 253 or any(c.isspace() for c in value) or "/" in value:
        raise ValueError(f"{label}格式无效")
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        if not re.fullmatch(r"(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", value) or ".." in value:
            raise ValueError(f"{label}格式无效") from None
        if any(not part or len(part) > 63 or part.startswith("-") or part.endswith("-") for part in value.split(".")):
            raise ValueError(f"{label}格式无效")
        return value.lower()


def _port(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 65535:
        raise ValueError(f"{label}无效")
    return value


def _public_key(value: object) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{43}", value):
        raise ValueError("Reality Public Key无效")
    return value


def _short_id(value: object) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"(?:[0-9a-fA-F]{2}){1,8}", value):
        raise ValueError("Reality Short ID无效")
    return value.lower()


def _read_json(path: Path) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"运行配置读取失败：{path.name}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"运行配置结构无效：{path.name}")
    return value


def _index(items, key):
    result = {}
    duplicates = set()
    for item in items:
        value = item.get(key) if isinstance(item, dict) else None
        if not isinstance(value, str) or not value:
            continue
        if value in result:
            duplicates.add(value)
        else:
            result[value] = item
    return result, duplicates


def _metadata_nodes(state: dict):
    nodes = state.get("nodes")
    if not isinstance(nodes, list):
        raise ValueError("Global线路元数据缺失")
    by_email = {}
    by_uuid = {}
    for node in nodes:
        if not isinstance(node, dict):
            continue
        key, uid = node.get("key"), node.get("uuid")
        if isinstance(key, str) and _ID_RE.fullmatch(key):
            by_email.setdefault(key + "@home", []).append(node)
        if isinstance(uid, str):
            by_uuid.setdefault(uid, []).append(node)
    return by_email, by_uuid


def _route_map(config: dict):
    users = {}
    duplicate_users = set()
    duplicate_uuids = set()
    uuid_counts = {}
    selected_inbounds = []
    inbounds = config.get("inbounds")
    if not isinstance(inbounds, list):
        inbounds = []
    for inbound in inbounds:
        if not isinstance(inbound, dict) or inbound.get("protocol") != "vless":
            continue
        stream = inbound.get("streamSettings")
        if isinstance(stream, dict) and stream.get("security") == "reality":
            selected_inbounds.append(inbound)
        settings = inbound.get("settings")
        clients = settings.get("clients") if isinstance(settings, dict) else None
        if not isinstance(clients, list):
            continue
        for client in clients:
            if not isinstance(client, dict):
                continue
            uid, email = client.get("id"), client.get("email")
            if not isinstance(uid, str) or not isinstance(email, str) or not email:
                continue
            if email in users:
                duplicate_users.add(email)
            users[email] = uid
            uuid_counts[uid] = uuid_counts.get(uid, 0) + 1

    duplicate_uuids.update(uid for uid, count in uuid_counts.items() if count > 1)

    rules = config.get("routing", {}).get("rules", []) if isinstance(config.get("routing"), dict) else []
    routes = {}
    for rule in rules if isinstance(rules, list) else []:
        if not isinstance(rule, dict) or not isinstance(rule.get("outboundTag"), str):
            continue
        emails = rule.get("user")
        if not isinstance(emails, list):
            continue
        for email in emails:
            if isinstance(email, str):
                routes.setdefault(email, []).append(rule["outboundTag"])

    outbounds, duplicate_tags = _index(config.get("outbounds", []) if isinstance(config.get("outbounds"), list) else [], "tag")
    if len(selected_inbounds) != 1:
        raise ValueError("当前运行配置必须包含唯一的VLESS Reality入站")
    inbound = selected_inbounds[0]
    stream = inbound.get("streamSettings", {})
    reality = stream.get("realitySettings", {}) if isinstance(stream, dict) else {}
    server_names = reality.get("serverNames") if isinstance(reality, dict) else None
    short_ids = reality.get("shortIds") if isinstance(reality, dict) else None
    clients = inbound.get("settings", {}).get("clients", []) if isinstance(inbound.get("settings"), dict) else []
    flows = {client.get("flow") for client in clients if isinstance(client, dict)}
    return users, duplicate_users, duplicate_uuids, routes, outbounds, duplicate_tags, stream, reality, server_names, short_ids, flows


def build_relay_export(config: dict, state: dict, audit, generated_at: str | None = None) -> dict:
    """Map real Xray identities and routes, exporting only complete SOCKS exits."""
    if not isinstance(config, dict) or not isinstance(state, dict):
        raise ValueError("运行配置结构无效")
    settings = state.get("settings")
    if not isinstance(settings, dict):
        raise ValueError("Global公共参数缺失")
    server = _host(settings.get("public_host"), "Global公网IP")
    external_port = _port(settings.get("external_port"), "Global公网映射端口")
    users, duplicate_users, duplicate_uuids, routes, outbounds, duplicate_tags, stream, reality, server_names, short_ids, flows = _route_map(config)
    if stream.get("network") not in ("tcp", "raw"):
        raise ValueError("当前Xray Reality入站不是TCP")
    if not isinstance(server_names, list) or len(server_names) != 1:
        raise ValueError("当前Xray Reality SNI不能唯一确定")
    sni = _host(server_names[0], "Reality SNI")
    if sni != _host(settings.get("sni"), "登记的Reality SNI"):
        raise ValueError("当前Xray Reality SNI与Global线路元数据不一致")
    if not isinstance(short_ids, list) or len(short_ids) != 1 or _short_id(short_ids[0]) != _short_id(settings.get("short_id")):
        raise ValueError("当前Xray Reality Short ID与Global线路元数据不一致")
    if reality.get("privateKey") != settings.get("private_key"):
        raise ValueError("当前Xray Reality Private Key与Global线路元数据不一致")
    if flows != {"xtls-rprx-vision"}:
        raise ValueError("当前Xray用户Flow不是统一的xtls-rprx-vision")
    public_key = _public_key(settings.get("public_key"))
    short_id = _short_id(short_ids[0])
    if settings.get("fingerprint", "chrome") != "chrome":
        raise ValueError("当前Global Reality指纹不是支持的chrome")

    by_email, by_uuid = _metadata_nodes(state)
    audit_by_key = {}
    for result in audit if isinstance(audit, list) else []:
        if isinstance(result, dict) and isinstance(result.get("key"), str):
            audit_by_key[result["key"]] = result

    exits, anomalies = [], []
    seen_ids = set()
    for email, uid in users.items():
        candidates = by_email.get(email, [])
        if len(candidates) != 1 or uid in duplicate_users or uid in duplicate_uuids or uid not in by_uuid or len(by_uuid[uid]) != 1:
            # Ignore unrelated Xray users without exposing their identity or UUID.
            if candidates or any(node.get("uuid") == uid for node in state.get("nodes", []) if isinstance(node, dict)):
                anomalies.append({"id": "unresolved-global-exit", "name": "未匹配到唯一线路元数据", "route_valid": False, "reason": "Xray用户与线路元数据无法唯一对应"})
            continue
        node = candidates[0]
        key = node["key"]
        line_id = "global-" + key
        if line_id in seen_ids:
            anomalies.append({"id": line_id, "name": node.get("name", line_id), "route_valid": False, "reason": "线路ID重复"})
            continue
        seen_ids.add(line_id)
        reasons = []
        matched_tags = routes.get(email, [])
        if len(matched_tags) != 1:
            reasons.append("UUID/email未对应唯一Xray路由")
            tag = None
        else:
            tag = matched_tags[0]
        if tag in duplicate_tags:
            reasons.append("Xray出站标签重复")
        outbound = outbounds.get(tag) if tag else None
        if not isinstance(outbound, dict) or outbound.get("protocol") != "socks":
            reasons.append("路由目标不存在或不是SOCKS出站")
            socks_server = None
            socks_port = None
        else:
            outbound_settings = outbound.get("settings")
            servers = outbound_settings.get("servers") if isinstance(outbound_settings, dict) else None
            if not isinstance(servers, list) or len(servers) != 1 or not isinstance(servers[0], dict):
                reasons.append("SOCKS出站服务器不能唯一确定")
                socks_server = None
                socks_port = None
            else:
                upstream = servers[0]
                try:
                    socks_server = _host(upstream.get("address"), "SOCKS地址")
                    socks_port = _port(upstream.get("port"), "SOCKS端口")
                except ValueError:
                    socks_server = None
                    socks_port = None
                    reasons.append("SOCKS地址或端口无效")
                if socks_server is not None and (socks_server != node.get("server") or socks_port != node.get("port")):
                    reasons.append("当前Xray SOCKS地址与线路登记值不一致")
        name = node.get("name") if isinstance(node.get("name"), str) and node["name"].strip() else line_id
        if reasons:
            anomalies.append({"id": line_id, "name": name, "route_valid": False, "reason": "；".join(dict.fromkeys(reasons))})
            continue
        audit_row = audit_by_key.get(key, {})
        expected_ip = None
        if audit_row.get("ok") is True:
            try:
                expected_ip = str(ipaddress.ip_address(audit_row.get("ip")))
            except ValueError:
                expected_ip = None
        entry = {
            "id": line_id,
            "name": name,
            "uuid": uid,
            "email": email,
            "outbound_tag": tag,
            "socks5": {"server": socks_server, "port": socks_port},
            "enabled": True,
            "route_valid": True,
        }
        if expected_ip:
            entry["expected_exit_ip"] = expected_ip
        country = node.get("country")
        if isinstance(country, str) and re.fullmatch(r"[A-Z]{2}", country):
            entry["country"] = country
        exits.append(entry)

    active_emails = set(users)
    for node in state.get("nodes", []):
        if not isinstance(node, dict) or not isinstance(node.get("key"), str):
            continue
        email = node["key"] + "@home"
        if email not in active_emails:
            anomalies.append({"id": "global-" + node["key"], "name": node.get("name", "Global线路"), "route_valid": False, "reason": "线路元数据未对应当前Xray入站用户"})

    stamp = generated_at or _dt.datetime.now(_dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    exits.sort(key=lambda row: row["id"])
    anomalies.sort(key=lambda row: (row["id"], row["reason"]))
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": KIND,
        "generated_at": stamp,
        "profile": {
            "profile_id": settings.get("profile_id", "global-home-main"),
            "name": settings.get("profile_name", "Global Home"),
            "server": server,
            "public_port": external_port,
            "network": "tcp",
            "security": "reality",
            "sni": sni,
            "fingerprint": "chrome",
            "flow": "xtls-rprx-vision",
            "public_key": public_key,
            "short_id": short_id,
        },
        "exits": exits,
        "anomalies": anomalies,
    }


def write_relay_export(config: dict, state: dict, audit, root: Path = DEFAULT_EXPORT_ROOT,
                       generated_at: str | None = None, service_active: bool = True) -> Path:
    if not service_active:
        raise RuntimeError("Global Home Xray服务未运行，拒绝导出非运行中的配置")
    document = build_relay_export(config, state, audit, generated_at)
    return write_relay_export_from_document(document, root)


def export_from_runtime(root: Path, export_root: Path = DEFAULT_EXPORT_ROOT, service_active: bool = True) -> Path:
    """Read only this tool's current generation, which is the service config source."""
    document = read_runtime_export(root)
    if not service_active:
        raise RuntimeError("Global Home Xray服务未运行，拒绝导出非运行中的配置")
    return write_relay_export_from_document(document, export_root)


def read_runtime_export(root: Path) -> dict:
    """Return a public-only document from the tool's active configuration source."""
    config, state, audit = load_runtime_generation(root)
    return build_relay_export(config, state, audit)


def load_runtime_generation(root: Path):
    """Read the current managed generation; never scans unrelated system configs."""
    root = Path(root)
    current = root / "current"
    if not current.is_symlink():
        raise RuntimeError("当前没有Global Home受管运行代")
    generation = current.resolve(strict=True)
    if generation.parent != (root / "generations").resolve():
        raise RuntimeError("当前运行代不属于Global Home，拒绝读取")
    config = _read_json(generation / "config.json")
    state = _read_json(generation / "state.private.json")
    audit = _read_json(generation / "upstream-audit.json")
    if not isinstance(audit, list):
        raise RuntimeError("家宽线路检测记录无效")
    return config, state, audit


def write_relay_export_from_document(document: dict, root: Path = DEFAULT_EXPORT_ROOT) -> Path:
    root = Path(root)
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    root.chmod(0o700)
    target = root / "dogma-relay.json"
    fd, temp_name = tempfile.mkstemp(prefix=".dogma-relay.", dir=str(root))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            os.fchmod(stream.fileno(), 0o600)
            json.dump(document, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, target)
        target.chmod(0o600)
        try:
            dir_fd = os.open(root, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError:
            # Windows test hosts cannot open directories for fsync; Alpine can.
            pass
    except BaseException:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise
    return target
